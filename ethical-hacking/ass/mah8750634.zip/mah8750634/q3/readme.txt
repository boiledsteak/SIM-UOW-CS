documentation for CSCI369 Ethical Hacking assignment Q3

initially I used dirb, a CLI directory crawler tool

attacker kali to run
	python3 run_dirb.py

the URLs from metasploitable vm, that match the wordlist, would be printed in terminal and also saved as an output file

run-dirb.py essentially runs 2 commands. dirb and grep.

dirb is a CLI tool that performs dictionary attack on a target URL.

From the output of the dirb command, the .py will grep the URLs that return these HTTP response codes
200
403
401
301
302
405

these response codes mean that the directory likely exists


then in accordance to assignment specification, I created a python program to perform the same task

attacker kali to run
	python3 not_dirb.py

similarly, the program will access the directories specified in the wordlist. 
If the directory returns an "alive" http response code, the "alive" directory is printed in terminal