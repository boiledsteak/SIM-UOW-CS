import subprocess

target = "http://192.168.181.135/mutillidae"
wordlist = "dirs.txt"
output_file = "dirb-output.txt"

# dirb
dirb_command = f"dirb {target} {wordlist} -o {output_file} -v"
print("Running dirb...")
subprocess.run(dirb_command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# filter out found URLs
grep_command = f"grep -E '(CODE:200|CODE:403|CODE:401|CODE:301|CODE:302|CODE:405)' {output_file}"
grep_process = subprocess.run(grep_command, shell=True, text=True, capture_output=True, check=True)

# Print the filtered output
print("Filtered URLs:")
print(grep_process.stdout)