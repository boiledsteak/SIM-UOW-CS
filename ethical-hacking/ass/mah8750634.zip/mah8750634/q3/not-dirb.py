import requests

meta_ip = "192.168.181.135"
target_website = "http://" + meta_ip + "/mutillidae"

# Load directories from the file
with open("dirs.txt", "r") as file:
    directories = [line.strip() for line in file if line.strip()]

for directory in directories:
    url = target_website + "/" + directory
    try:
        response = requests.get(url)
        # Check if the response code is within the range of success codes
        if response.status_code in [200, 301, 302, 403, 401, 405]:
            print(f"Directory '{directory}' is Alive: {response.status_code} - {url}")
    except requests.RequestException as e:
        print(f"Error checking '{directory}': {e}")