import hashlib
import itertools
import string

def find_salts(hash_file, plaintext_file):
    # Generate all possible A values (two lowercase letters)
    letters = string.ascii_lowercase
    a_combinations = [''.join(pair) for pair in itertools.product(letters, repeat=2)]

    # Generate all possible B values (symbols)
    symbols = '`~!@#$%^&*()_+-=[]{}|;:\'",.<>/?\\'
    b_combinations = [''.join(pair) for pair in itertools.product(symbols, repeat=2)]

    # Read the possible hashes and plaintexts from files
    with open(hash_file, 'r') as hashes, open(plaintext_file, 'r') as plaintexts:
        for known_hash, pw in zip(hashes, plaintexts):
            known_hash = known_hash.strip()
            pw = pw.strip()

            # Brute force all combinations of A and B
            found = False
            for a in a_combinations:
                for b in b_combinations:
                    input_string = f"{a}{pw}{b}"
                    hash_object = hashlib.md5(input_string.encode())
                    voucher_code = hash_object.hexdigest()
                    if voucher_code == known_hash:
                        print(f"Match found: A = {a}, B = {b} for ClientID = {pw} with hash {known_hash}")
                        found = True
                        break
                if found:
                    break
            if not found:
                print(f"No match found for plaintext password = {pw} with hash {known_hash}")

# Usage example
hash_file = 'the-hash.txt'
plaintext_file = 'the-pw.txt'
find_salts(hash_file, plaintext_file)
